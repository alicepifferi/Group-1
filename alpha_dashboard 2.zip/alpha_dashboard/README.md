# Alpha Manufacturing Employee Retention Dashboard (v2)

Group 1: Alice Pifferi, Konstanze Hofmann, John Zaslow · DATA 6520

## Run it
```
cd ~/Desktop/alpha_dashboard
pip3 install -r requirements.txt
python3 -m streamlit run app.py
```
Sign in with your own Supabase email and password. Nothing is saved.

## Pages (sidebar)
1. **Overview**: headline numbers and the four patterns that matter most
2. **Where they leave**: department, department x pay band, plant and shift, month
3. **Who leaves**: workload, time at Alpha, leavers vs stayers (survey)
4. **Why they leave**: exit reasons and the Say vs Leave check
5. **ROI Simulator**: would a pay raise pay for itself?
6. **Recommendations**: three actions with target reason, benefit, cost, tracking metric
7. **About the data**: metric definitions, worked example, validation counts, data checks

Five sidebar filters (department, salary band, plant, shift, job role) apply to pages 1 to 4 and the validation counts.

## How it meets the backlog
- Story 3: metric table with formula, population and time window, plus a worked example
- Story 4: groups and months, leavers vs stayers, response counts and limits
- Story 5: Python + Streamlit, read-only login, no caching or files, 5 filters, 60 s refresh
- Story 6: validation counts for any filter combination; clear error if the connection fails
- Story 7: sourced cost assumptions, 5% and 10% scenarios labeled hypothetical, 3 recommendations

## Dark theme
The look comes from the hidden `.streamlit` folder (`config.toml`). Keep it next to `app.py`.
On a Mac, press Cmd + Shift + . in Finder to see hidden folders. Upload it to GitHub too.

## Security
Never commit passwords, tokens, .RData files or CSV exports.
